SV-Netzwerk ClaimsForce-Brücke

1. ZIP-Datei entpacken.
2. In Chrome chrome://extensions öffnen und den Entwicklermodus einschalten.
3. "Entpackte Erweiterung laden" wählen und diesen Ordner auswählen.
4. "Details" / "Erweiterungsoptionen" öffnen und die persönlichen ClaimsForce-Zugangsdaten einmalig speichern. Ist der lokale Zugangsdaten-Helfer mit dem freigegebenen Zugangsdatenordner verbunden, übernimmt die Brücke die benötigten Zugänge automatisch und speichert sie verschlüsselt im Chrome-Profil.
5. Im SV-Netzwerk unter Versicherungsfälle "Aufträge aus Claims einlesen" wählen.

Bei Susanne bestimmt die Auswahl "Bearbeitung für", in welchen persönlichen Fallordner importiert wird.
Manuell geänderte Falldaten werden nicht überschrieben. Neue ClaimsForce-Werte ergänzen nur bisher leere Felder.
Bereits vollständig importierte und unveränderte Fälle werden übersprungen. Bei Änderungen werden nur neue oder geänderte Unterlagen, Nachrichten und Termine ergänzt.
Vor einer namentlichen Anmeldung entfernt die Brücke ausschließlich die Sitzungsdaten von ClaimsForce und ClaimsForce-Auth0. Dadurch können alte Chrome-Autofill- oder SSO-Sitzungen nicht mehr versehentlich unter dem neu ausgewählten Profil weiterlaufen.
